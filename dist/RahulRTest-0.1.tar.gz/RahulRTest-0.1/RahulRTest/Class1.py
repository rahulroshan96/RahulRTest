class Class1(object):
    def __init__(self):
        print("Class 1 initialized")
